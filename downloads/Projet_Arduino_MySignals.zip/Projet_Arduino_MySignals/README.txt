Arduino-Messstation fuer Puls und Temperatur

Code: Arduino-Sketches
Bibliotheken: ZIP-Dateien fuer die Bibliotheken und das TftGui-Beispiel
Dokumentation: Dokumentation_Arduino_MySignals.pdf
Demonstration: Video und Bilder
