

#include <Adafruit_GFX_AS.h>
#include <Adafruit_ILI9341_AS.h>
#include <MySignals.h>
// den Anzeigebereich des Graphen auf der Linken Seite verschieben 
#define graphic_low_extrem 230
#define graphic_high_extrem 30
#define graphic_left_extrem 30 // 0 zu 30 
#define graphic_right_extrem 320


Adafruit_ILI9341_AS tft = Adafruit_ILI9341_AS(TFT_CS, TFT_DC);

// den Anzeigebereich des Graphen auf der Linken Seite verschieben 
//! It stores the current value of x position in the LCD.
uint16_t graphic_x= graphic_left_extrem;
//! It stores the current value of the MySignals. 
uint16_t valRead;
//! It stores the previous value of the MySignals. 
uint16_t graphic_prevRead;


void setup(void) 
{
  Serial.begin(9600);
  
  MySignals.begin();
    
 tft.init();
  tft.setRotation(3);
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_RED);
  tft.setTextColor(ILI9341_WHITE); 
  
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_ORANGE);
  tft.setTextColor(ILI9341_BLACK); 
  tft.drawString("Temperature",5,5,4);

  
  //tft.println();
  //tft.println();
  //tft.println();
  //tft.println();
   Serial.println(valRead);
  valRead = map(valRead, 200, 400, 230, 30);
  printGraphic(valRead, 450);
 

  
  
  


}

void loop() 
{

  valRead = (float)MySignals.getTemperature()*10.0;
   
  Serial.println(valRead);
  
  valRead = map(valRead,450, 550, 230, 30);
  printGraphic(valRead, 450);

  

  
  tft.fillRect(249,5,70,25,ILI9341_ORANGE);
  tft.setTextColor(ILI9341_WHITE);
tft.drawNumber(valRead,150, 60, 4);
// printGraphic(valRead, 0);
  
}



void printGraphic(uint16_t value, uint8_t delay_time)
{

  if (value < graphic_high_extrem)
  {
    value = graphic_high_extrem;
  }
  if (value > graphic_low_extrem)
  {
    value = graphic_low_extrem;
  }


  //Pinta la linea solo a partir de que ya exista al menos 1 valor
  if (graphic_x > graphic_left_extrem + 1)
  {
    tft.drawLine(graphic_x - 1, graphic_prevRead, graphic_x, value, ILI9341_RED);
  }

  //Wave refresh (barre pantalla pintando una linea)
  tft.drawLine(graphic_x + 1, graphic_high_extrem, graphic_x + 1, graphic_low_extrem, ILI9341_WHITE);


  graphic_prevRead = value;
  graphic_x++;

  delay(delay_time);

  if (graphic_x == graphic_right_extrem)
  {
    graphic_x = graphic_left_extrem;
  }
  SPI.end();
}
