/*
  TftGuiExample -- Example for implementing a Gui on an MySignals board using the TftGui library (using a 320x240 TFT screen with ILI9341)

  v0.1 : created 10 Jan 2022 by Heiko Huebert

  This code is only intended for use within the course "M25 Mikrocomputertechnik" at HTW Berlin 
  
*/

/* Code is partly based on MySignals examples : https://www.cooking-hacks.com/mysignals-hw-v1-ehealth-medical-biometric-iot-platform-arduino-tutorial/index.html
 *   tft_touchscreen
 *   sensor_temperature_tft
 * for those elements the following license applies:

   Copyright (C) 2016 Libelium Comunicaciones Distribuidas S.L.
   http://www.libelium.com

    By using it you accept the MySignals Terms and Conditions.
    You can find them at: http://libelium.com/legal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Version:           0.1
    Design:            David Gascon
    Implementation:    Luis Martin / Victor Boria
*/
#include <MySignals.h>
#include <sounddata.h>
#include <Adafruit_ILI9341_AS.h>
#include <Adafruit_GFX_AS.h>
#include <Font16.h>
#include <Font32.h>
#include <Font64.h>
#include <Font7s.h>
#include <Load_fonts.h>
#define graphic_low_extrem 230
#define graphic_high_extrem 30
#define graphic_left_extrem 30
#define graphic_right_extrem 320
#include <PulseSensorPlayground.h>


#include <MySignals_Extender.h>



PulseSensorPlayground pulseSensor;

#include <MySignals.h>
#include <MySignals_Extender.h>
#include <Adafruit_GFX_AS.h>
#include <Adafruit_ILI9341_AS.h>
#include <TftGui.h>
#include <UTouch.h>

#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978












// create TFT object
Adafruit_ILI9341_AS tft = Adafruit_ILI9341_AS(TFT_CS, TFT_DC);

// create touch object
#define INVERTED_TOUCHSCREEN 1
#define TOUCH_SAMPLING_RATE_IN_MS 300
UTouch myTouch(TOUCH_CLK, TOUCH_CS, TOUCH_DIN, TOUCH_DOUT, TOUCH_IRQ);
TouchGui touch(&myTouch,TOUCH_SAMPLING_RATE_IN_MS,INVERTED_TOUCHSCREEN);

// craeate screen 1 and define variables for its GUI element IDs
ScreenGui screen1(&tft, "Display 1");
uint8_t ButtonLED     = 0;
uint8_t ButtonScreen2 = 0;
uint8_t ButtonScreen3 = 0;
uint8_t TempDisplay   = 0;
uint8_t TempIndicator = 0;

// craeate screen 2 and define variables for its GUI element IDs
ScreenGui screen2(&tft, "Display 2");
uint8_t ButtonBack  = 0;
uint8_t TempDiagram = 0;

// craeate screen 3and define variables for its GUI element IDs
ScreenGui screen3(&tft, "Herzschlag");
uint8_t ButtonBack1  = 0;


// current screen number
uint8_t currentScreen = 1;

const byte ledPin3 = 12;
const byte interruptPin = 18;
volatile byte state = LOW;

void blink() {
state = !state;
}

// main setup
void setup(void) 
{
  pinMode(ledPin3, OUTPUT);
pinMode(interruptPin, INPUT_PULLUP);
attachInterrupt(digitalPinToInterrupt(interruptPin), blink, FALLING);
  Serial.begin(115200);
  MySignals.begin();
  tft.init();

  // this code is necessary for the touch initialization, don't change it
  // ... based on MySignals examples tft_touchscreen : https://www.cooking-hacks.com/mysignals-hw-v1-ehealth-medical-biometric-iot-platform-arduino-tutorial/index.html
  //expanderState is initialized with B10000001;
  bitSet(MySignals.expanderState, EXP_TOUCH_CS);  //Enable Touchscreen SPI
  MySignals.expanderWrite(MySignals.expanderState);
  Wire.begin();
  touch.init();

  // create screen1 GUI elements
  ButtonLED      = screen1.addButton(10, 30, "ON/OFF");
  ButtonScreen2  = screen1.addButton(10, 100, "Screen2");
  ButtonScreen3  = screen1.addButton(10, 180, "Screen3");
  TempDisplay    = screen1.addTextBox(200, 50, "Temp");
  TempIndicator  = screen1.addIndicator(250, 175, "gut");

  // create screen2 GUI elements
  ButtonBack     = screen2.addSmallButton(260,  2, "back");
  TempDiagram    = screen2.addDiagram(0, 30, 200, 400,"");

// create screen3 GUI elements
  ButtonBack     = screen3.addSmallButton(150,  2, "back");


  if (currentScreen == 1) {
    screen1.init();
  }
  else if(currentScreen == 2) {
    screen2.init();
  }
  else if(currentScreen == 3){
    screen3.init();
    }
    else {
      screen1.init();
    }
  pinMode(LED1, OUTPUT);
}

// define update interval in ms
#define UPDATE_INTERVAL_SCREEN1 500
#define UPDATE_INTERVAL_SCREEN2 10
#define UPDATE_INTERVAL_SCREEN3 10
unsigned long lastUpdate = 0;

// main loop
void loop(void) 
{
digitalWrite(ledPin3, state);

  
  // get time since last screen update
  unsigned long timeElapse  = millis() - lastUpdate;
  
  // check for current screen and run the corresponding code
  if (currentScreen == 1) {
    if (timeElapse > UPDATE_INTERVAL_SCREEN1) {
      screen1_loop();
      lastUpdate += timeElapse;
    }
    if (touch.gotEvent()) screen1_checkTouch();
  }
  
  else if (currentScreen == 2) 
  {
    if (timeElapse > UPDATE_INTERVAL_SCREEN2) {
      screen2_loop();
      lastUpdate += timeElapse;
    }
    if (touch.gotEvent()) screen2_checkTouch();
  }
   else {
    if (timeElapse > UPDATE_INTERVAL_SCREEN3) {
      screen3_loop();
      lastUpdate += timeElapse;
    }
    if (touch.gotEvent()) screen3_checkTouch();
  }

}


//////////////////////////////////// code for screen 1 ////////////////////////////////////
boolean toogle_LED = false;

void screen1_loop()
{
  // read current temperature
  uint16_t currentTemp = (float)MySignals.getTemperature() * 10.0;

  // update temperature value display
  screen1.updateLabel(TempDisplay, String(((float)currentTemp) / 10.0, 1));

  // update indicator
  if (currentTemp > 250) 
  {
    screen1.updateLabel(TempIndicator, "HIGH");
    screen1.updateColor(TempIndicator, ILI9341_RED);
  }
  else 
  {
    screen1.updateLabel(TempIndicator, "NORM");
    screen1.updateColor(TempIndicator, ILI9341_GREEN);
  }

  
  // toogle LED (based on button press)
  if (toogle_LED == true) 
  {
    digitalWrite(LED1, HIGH);
  }
  else 
  {
    digitalWrite(LED1, LOW);
  }
}

void screen1_checkTouch()
{
  // read button to toggle LED (on/off)
  if (screen1.touched(ButtonLED, touch.getLocation())) 
  {
    toogle_LED = !toogle_LED;
  }
  // read button to switch to screen 2
  else if (screen1.touched(ButtonScreen2, touch.getLocation())) 
  {
    screen2.init();
    currentScreen = 2;
  }
   else if (screen1.touched(ButtonScreen3, touch.getLocation())) 
  {
    screen3.init();
    screen3_setup();
    
    currentScreen = 3;
  }
}



//////////////////////////////////// code for screen 2 ////////////////////////////////////
void screen2_loop()
{
  // read current temperature
  int16_t currentTemp = (float)MySignals.getTemperature() * 10.0;

  // update diagram with current temperature value
  screen2.updateValue(TempDiagram, currentTemp);
}

void screen2_checkTouch()
{
  // read button to switch to screen 1
  if (screen2.touched(ButtonBack, touch.getLocation())) 
  {
    screen1.init();
    currentScreen = 1;
  }
}
//////////////////////////////////// code for screen 3 ////////////////////////////////////

//Adafruit_ILI9341_AS tft = Adafruit_ILI9341_AS(TFT_CS, TFT_DC);
//! It stores the current value of x position in the LCD.
uint16_t graphic_x = graphic_left_extrem;
//! It stores the current value of the MySignals. 
uint16_t valRead;
//! It stores the previous value of the MySignals. 
uint16_t graphic_prevRead;


int rawValue;
  
  
bool heartbeatDetected(int A8, int delay)
{
  static int maxValue = 0;
  static bool isPeak = false;
    
    
  bool result = false;
      
  rawValue = analogRead(A8);
  
  // Hier wird der aktuelle Spannungswert am Fototransistor ausgelesen und in der rawValue-Variable zwischengespeichert
  
  rawValue *= (1000/delay);
  
  // Sollte der aktuelle Wert vom letzten maximalen Wert zu weit abweichen
  // (z.B. da der Finger neu aufgesetzt oder weggenommen wurde)
  // So wird der MaxValue resetiert, um eine neue Basis zu erhalten.
  
  if (rawValue * 4L < maxValue) {    maxValue = rawValue * 0.8;  }     // Detect new peak
  if (rawValue > maxValue - (1000/delay)) {
    
    // Hier wird der eigentliche Peak detektiert. Sollte ein neuer RawValue groeßer sein
    // als der letzte maximale Wert, so wird das als Spitze der aufgezeichnten Daten erkannt.
    if (rawValue > maxValue) {
      maxValue = rawValue;
    }
    // Zum erkannten Peak soll nur ein Herzschlag zugewiesen werden
    if (isPeak == false) {
      result = true;
    }
    isPeak = true;
  } else if (rawValue < maxValue - (3000/delay)) {
    isPeak = false;
    // Hierbei wird der maximale Wert bei jeden Durchlauf
    // etwas wieder herabgesetzt. Dies hat den Grund, dass
    // nicht nur der Wert sonst immer stabil bei jedem Schlag
    // gleich oder kleiner werden wuerde, sondern auch,
    // falls der Finger sich minimal bewegen sollte und somit
    // das Signal generell schwaecher werden wuerde.
    maxValue-=(1000/delay);
 }
  return result;
}
  
  
////////////////////////////////////////////////////////////////////////
// Arduino main code
////////////////////////////////////////////////////////////////////////
int ledPin=11;
int ledPin2=13;
int analogPin=0;
int tonePin=9;
// notes in the melody:
int melody[] = {
  NOTE_C4, NOTE_G3,NOTE_G3, NOTE_A3, NOTE_G3,0, NOTE_B3, NOTE_C4};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
int noteDurations[] = {
  4, 8, 8, 4,4,4,4,4 };
void screen3_setup()
{
  // Die eingebaute Arduino LED (Digital 13), wird hier zur Ausgabe genutzt
  pinMode(ledPin,OUTPUT);
      pinMode(ledPin2,OUTPUT);
      pinMode(tonePin,OUTPUT);
      // iterate over the notes of the melody:
  

  // Serielle Ausgabe Initialisierung
  Serial.begin(9600);
  Serial.println("Heartbeat Detektion Beispielcode.");
  

  //Serial.begin(115200);
  
  
    
  //tft.init();
  tft.setRotation(3);
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_RED);
  tft.setTextColor(ILI9341_WHITE); 
  
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_ORANGE);
  tft.setTextColor(ILI9341_BLACK); 
  tft.drawString("Herzschlag",5,5,4);

  
  //tft.println();
  //tft.println();
  //tft.println();
  //tft.println();
   Serial.println(valRead);
  valRead = map(valRead, 200, 400, 230, 30);
  printGraphic(valRead, 450);
 

  tft.drawLine(30,240,30,30,ILI9341_BLACK);
  
  tft.drawNumber(10,5,220,2);
  tft.drawNumber(20,5,200,2);
  tft.drawNumber(30,5,180,2);
  tft.drawNumber(40,5,160,2);
  tft.drawNumber(50,5,140,2);
  tft.drawNumber(60,5,120,2);
  tft.drawNumber(70,5,100,2);
  tft.drawNumber(80,5,80,2);
  tft.drawNumber(90,5,60,2);
  tft.drawNumber(100,5,40,2);
  tft.drawNumber(110,5,40,2);
  }
const int delayMsec = 60; // 100msec per sample
  
// Das Hauptprogramm hat zwei Aufgaben: 
// - Wird ein Herzschlag erkannt, so blinkt die LED kurz aufgesetzt
// - Der Puls wird errechnet und auf der serriellen Ausgabe ausgegeben.
// boolean toogle_LED = false;
  int noteDuration=0;


void screen3_loop()
{
 // read the input on analog pin 0:
  int sensorValue = analogRead(A8);
  
  // print out the value you read:
  Serial.print("450 550 ");
  Serial.println(sensorValue);
   
  delay(10);        
  valRead = sensorValue   ;
  tft.fillRect(249,5,70,25,ILI9341_BLACK);
  tft.setTextColor(ILI9341_WHITE);
  tft.drawNumber(valRead,249,5,4);
  Serial.println(valRead);
  valRead = map(valRead, 450, 550, 230, 30);
  printGraphic(valRead, 0);
  
  static int beatMsec = 0;
  int heartRateBPM = 0;
  
  if (heartbeatDetected(analogPin, delayMsec)) {
    heartRateBPM = 60000 / beatMsec;
    // LED-Ausgabe bei Herzschlag
    //digitalWrite(ledPin,3);
    //tonePin,9,2000,1;
    
  
    // Serielle Datenausgabe
    Serial.print(" Puls erkannt: ");
    Serial.println(heartRateBPM);
    
    //Monitor AufGabe
    beatMsec = 0;
  }
  
  else {
    digitalWrite(ledPin,0);
  }
  //der durchschnittliche Ruhepuls eines gesunden Erwachsenen liegt zwischen 60 bis 90
  //wenn der puls <90 ist dann wird "Puls niedrig" in der konsole geschreiben und wird der rote LED blinken.und Ausserdem wird noch ein tone erzeugt

  if (sensorValue<60)
  {
        Serial.print(" Puls niedrig");
  digitalWrite(ledPin2,0);
  delay(100);
  digitalWrite(ledPin2,1);
  delay(100);
  
 /* for (int thisNote = 0; thisNote < 8; thisNote++) 
{ 
  noteDuration = 1000/noteDurations[thisNote];
   tone(BUZZER, melody[thisNote],noteDuration);
   delay(noteDuration * 1.30);
//     stop the tone playing:
   noTone(BUZZER);
}*/


  }

//wenn der puls >90 ist dann wird "Puls hoch" in der konsole geschreiben und wird der rote LED blinken.und Ausserdem wird noch ein tone erzeugt

else if (sensorValue>90)
{
  Serial.print(" Puls hoch");
  digitalWrite(ledPin2,0);
  delay(100);
  digitalWrite(ledPin2,1);
  delay(100);
/* for (int thisNote = 0; thisNote < 8; thisNote++) 
{ 
  noteDuration = 1000/noteDurations[thisNote];
   tone(BUZZER, melody[thisNote],noteDuration);
   delay(noteDuration * 1.30);
//     stop the tone playing:
   noTone(BUZZER);
}*/
}
//wenn der puls zwischen 60 und 90 ist dann wird "sie sind Gesund" in der konsole geschreiben und wird der Gruner LED blinken
else
{
Serial.print(" sie sind Gesund");
  digitalWrite(ledPin,0);
  delay(100);
           digitalWrite(ledPin,1);
  delay(100);
}
  
    
  delay(delayMsec);
 beatMsec += delayMsec;
}
  
  
void printGraphic(uint16_t value, uint8_t delay_time)
{

  if (value < graphic_high_extrem)
  {
    value = graphic_high_extrem;
  }
  if (value > graphic_low_extrem)
  {
    value = graphic_low_extrem;
  }
   //Pinta la linea solo a partir de que ya exista al menos 1 valor
  if (graphic_x > graphic_left_extrem + 1)
  {
    tft.drawLine(graphic_x - 1, graphic_prevRead, graphic_x, value, ILI9341_RED);
  }

  //Wave refresh (barre pantalla pintando una linea)
  tft.drawLine(graphic_x + 1, graphic_high_extrem, graphic_x + 1, graphic_low_extrem, ILI9341_WHITE);


  graphic_prevRead = value;
  graphic_x++;

  delay(delay_time);

  if (graphic_x == graphic_right_extrem)
  {
    graphic_x = graphic_left_extrem;
  }
  SPI.end();

}

void screen3_checkTouch()
{
  // read button to switch to screen 1
 if (screen3.touched(ButtonBack, touch.getLocation())) 
  {
    screen1.init();
    currentScreen = 1;
  }
  
}
