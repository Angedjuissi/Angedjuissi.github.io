/*
 */
#define USE_ARDUINO_INTERRUPTS false
#include <PulseSensorPlayground.h>
#include<LiquidCrystal.h>
#include <Adafruit_GFX_AS.h>
#include <Adafruit_ILI9341_AS.h>
#include <MySignals.h>

#define graphic_low_extrem 230
#define graphic_high_extrem 30
#define graphic_left_extrem 30
#define graphic_right_extrem 320
#define ILI9341_BLACK 0x0000       ///<   0,   0,   0
#define ILI9341_BLUE 0x001F        ///<   0,   0, 255
#define ILI9341_RED 0xF800         ///< 255,   0,   0
#define ILI9341_WHITE 0xFFFF       ///< 255, 255, 255
#define ILI9341_PINK 0xFC18        ///< 255, 130, 198
#define ILI9341_GREEN 0x07E0       ///<   0, 255,   0

Adafruit_ILI9341_AS tft = Adafruit_ILI9341_AS(TFT_CS, TFT_DC);


//! It stores the current value of x position in the LCD.
uint16_t graphic_x = graphic_left_extrem; 
//! It stores the current value of the MySignals. 
uint16_t valRead;
//! It stores the previous value of the MySignals. 
uint16_t graphic_prevRead;


/*
   The format of our output.

   Set this to PROCESSING_VISUALIZER if you're going to run
    the Processing Visualizer Sketch.
    See https://github.com/WorldFamousElectronics/PulseSensor_Amped_Processing_Visualizer

   Set this to SERIAL_PLOTTER if you're going to run
    the Arduino IDE's Serial Plotter.
*/
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const int OUTPUT_TYPE = SERIAL_PLOTTER;

const int PULSE_INPUT = A0;  //PIN A0 is on Signal of Pulse sensor
const int PULSE_BLINK = 13;    // Pin 13 is the on-board LED
const int THRESHOLD = 516;   // A ajuster en fonction de votre montage
/*
   samplesUntilReport = the number of samples remaining to read
   until we want to report a sample over the serial connection.

   We want to report a sample value over the serial port
   only once every 20 milliseconds (10 samples) to avoid
   doing Serial output faster than the Arduino can send.
*/
byte samplesUntilReport;
const byte SAMPLES_PER_SERIAL_SAMPLE = 10;

/*
   All the PulseSensor Playground functions.
*/
PulseSensorPlayground pulseSensor;


/*LEDS
 */
int ledPins[] = {
  2, 3, 4, 5, 6, 7,8,9,10,11
};       // an array of pin numbers to which LEDs are attached
int pinCount = 10;  

//Valeur minimal du rythme cardiaque a afficher sur les leds
const byte bpmMin = 40;
const byte bpmMax = 110;

//SETUP
void setup() {
   Serial.begin(115200);
  
  MySignals.begin();
    
  tft.init();
  tft.setRotation(3);
  
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_RED);
  tft.setTextColor(ILI9341_WHITE); 
  tft.drawString("Herzschalg",5,5,4); 
  tft.drawPixel(0, 0,ILI9341_WHITE );                          // X-Wert, Y-Wert, Farbe (mögliche Farben siehe unten)
tft.drawLine(10, 6, 18,6,ILI9341_WHITE );     // X-Wert, Y-Wert, Width, Height, Farbe (xy links oben)
tft.fillRect(10, 6, 18, 6, ILI9341_RED);     // X-Wert, Y-Wert, Width, Height, Farbe (xy links oben)
tft.fillScreen(ILI9341_RED);                                               // X-Wert, Y-Wert, Width, Height, Farbe (xy links oben)
tft.setTextColor(ILI9341_WHITE);                                                 // Setzt die Farbe für den folgeden Text auf c (mögliche Farben siehe unten)
tft.drawString(char Bpm, int 20, int 9, int size); 
// String als char, X-Wert, Y-Wert, Größe (mögliche Textgrößen siehe unten)
tft.drawRightString(Bpm,10, 6, 4);
tft.drawNumber(long long_num,int poX, int poY, int size);
tft.drawFloat(float floatNumber,int decimal,int poX, int poY, int size);      // Float-Wert, Anzahl Nachkommastellen, X, Y, Größe


  // set up the LCD's number of columns and rows:
 lcd.begin(16, 2);
  
  Serial.begin(115200);

  // Configure the PulseSensor manager.
  pulseSensor.analogInput(PULSE_INPUT);
  pulseSensor.blinkOnPulse(PULSE_BLINK);
  pulseSensor.setSerial(Serial);
  pulseSensor.setOutputType(OUTPUT_TYPE);
  pulseSensor.setThreshold(THRESHOLD);

 //LEDS SETUP in Output
  for (int thisPin = 0; thisPin < pinCount; thisPin++) {
    pinMode(ledPins[thisPin], OUTPUT);
  }

  // Now that everything is ready, start reading the PulseSensor signal.
  if (!pulseSensor.begin()) {//FAILED
    /*
       PulseSensor initialization failed,
       likely because our Arduino platform interrupts
       aren't supported yet.

       If your Sketch hangs here, try changing USE_PS_INTERRUPT to false.
    */
    for(;;) {
      // Flash the led to show things didn't work.
      digitalWrite(PULSE_BLINK, LOW);
      delay(50);
      digitalWrite(PULSE_BLINK, HIGH);
      delay(50);
    }
  }
 
}

void loop() {

  /*
     See if a sample is ready from the PulseSensor.

     If USE_INTERRUPTS is true, the PulseSensor Playground
     will automatically read and process samples from
     the PulseSensor.

     If USE_INTERRUPTS is false, this call to sawNewSample()
     will, if enough time has passed, read and process a
     sample (analog voltage) from the PulseSensor.
  */
    



  
  if (pulseSensor.sawNewSample()) {
    /*
       Every so often, send the latest Sample.
       We don't print every sample, because our baud rate
       won't support that much I/O.
    */
    if (--samplesUntilReport == (byte) 0) {
      samplesUntilReport = SAMPLES_PER_SERIAL_SAMPLE;

      pulseSensor.outputSample();

      /*
         At about the beginning of every heartbeat,
         report the heart rate and inter-beat-interval.
      */
      if (pulseSensor.sawStartOfBeat()) {
        pulseSensor.outputBeat();
        int myBPM = pulseSensor.getBeatsPerMinute();

        Serial.println("♥  A HeartBeat Happened ! "); // If test is "true", print a message "a heartbeat happened".
        Serial.print("BPM: ");                        // Print phrase "BPM: " 
        Serial.println(myBPM);  

          if ( myBPM >= bpmMin && myBPM <= bpmMax ) {
           int purcent  = map(myBPM, bpmMin , bpmMax, 0, 100);
           lightLed100(purcent);
           delay(100);
           lightLed100(0);
           }else{
               lightLed100(0);
           }
       }
    }
  }

  /******
     Don't add code here, because it could slow the sampling
     from the PulseSensor.
  ******/
}


//Led on in purcentage
void lightLed100(int pourcent) {
  //put to LOW first
  for (int thisPin = 0; thisPin < pinCount; thisPin++) {
    digitalWrite(ledPins[thisPin], LOW);
  }
  
  //PINS TO HIGH

 int pinsToHigh  = map(pourcent, 0 , 100, 0, pinCount);
 
  for (int thisPin = 0; thisPin < pinsToHigh; thisPin++) {
    digitalWrite(ledPins[thisPin], HIGH);
  }
  
}
