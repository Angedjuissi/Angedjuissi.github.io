#include <MySignals.h>
#include <sounddata.h>
#include <Adafruit_ILI9341_AS.h>
#include <Adafruit_GFX_AS.h>
#include <Font16.h>
#include <Font32.h>
#include <Font64.h>
#include <Font7s.h>
#include <Load_fonts.h>
#define graphic_low_extrem 230
#define graphic_high_extrem 30
#define graphic_left_extrem 30
#define graphic_right_extrem 320
#include <PulseSensorPlayground.h>

#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978

#include <MySignals_Extender.h>



PulseSensorPlayground pulseSensor;



////////////////////////////////////////////////////////////////////////
/// Copyright (c)2015 Dan Truong
/// Permission is granted to use this software under the MIT
/// licence, with my name and copyright kept in source code
/// http://http://opensource.org/licenses/MIT
///
/// KY039 Arduino Heartrate Monitor V1.0 (April 02, 2015)
////////////////////////////////////////////////////////////////////////
  
// German Comments by Joy-IT
  
  
////////////////////////////////////////////////////////////////////////
/// @param[in] IRSensorPin Analog PI an welchen der Sensor angeschlossen ist
/// @param[in] delay (msec) Die Verzoegerung zwischen den Aufrufen der Abtastfunktion.
//                   Die besten Ergebnisse erhaelt man, wenn man 5 mal Pro Herzschlag abtastet.
///                  Nicht langsamer als 150mSec für z.B. 70 BPM Puls
///                  Besser waere 60 mSec für z.B. bis zu einen Puls von 200 BPM.
///
/// @Kurzbeschreibung
/// Dieser Code stellt eine sog. Peak-Detection dar.
/// Es wird kein Herzschlagverlauf aufgezeichnet, sondern es
/// wird innerhalb der aufgezeichneten Daten nach "Peaks" (Spitzen) gesucht, 
/// und per LED angezeigt. Mittels der bekannten Delay Abstaende, kann somit
/// grob der Puls errechnet werden.
////////////////////////////////////////////////////////////////////////
  
Adafruit_ILI9341_AS tft = Adafruit_ILI9341_AS(TFT_CS, TFT_DC);
//! It stores the current value of x position in the LCD.
uint16_t graphic_x = graphic_left_extrem;
//! It stores the current value of the MySignals. 
uint16_t valRead;
//! It stores the previous value of the MySignals. 
uint16_t graphic_prevRead;


int rawValue;
  
  
bool heartbeatDetected(int A8, int delay)
{
  static int maxValue = 0;
  static bool isPeak = false;
    
    
  bool result = false;
      
  rawValue = analogRead(A8);
  
  // Hier wird der aktuelle Spannungswert am Fototransistor ausgelesen und in der rawValue-Variable zwischengespeichert
  
  rawValue *= (1000/delay);
  
  // Sollte der aktuelle Wert vom letzten maximalen Wert zu weit abweichen
  // (z.B. da der Finger neu aufgesetzt oder weggenommen wurde)
  // So wird der MaxValue resetiert, um eine neue Basis zu erhalten.
  
  if (rawValue * 4L < maxValue) {    maxValue = rawValue * 0.8;  }     // Detect new peak
  if (rawValue > maxValue - (1000/delay)) {
    
    // Hier wird der eigentliche Peak detektiert. Sollte ein neuer RawValue groeßer sein
    // als der letzte maximale Wert, so wird das als Spitze der aufgezeichnten Daten erkannt.
    if (rawValue > maxValue) {
      maxValue = rawValue;
    }
    // Zum erkannten Peak soll nur ein Herzschlag zugewiesen werden
    if (isPeak == false) {
      result = true;
    }
    isPeak = true;
  } else if (rawValue < maxValue - (3000/delay)) {
    isPeak = false;
    // Hierbei wird der maximale Wert bei jeden Durchlauf
    // etwas wieder herabgesetzt. Dies hat den Grund, dass
    // nicht nur der Wert sonst immer stabil bei jedem Schlag
    // gleich oder kleiner werden wuerde, sondern auch,
    // falls der Finger sich minimal bewegen sollte und somit
    // das Signal generell schwaecher werden wuerde.
    maxValue-=(1000/delay);
 }
  return result;
}
  
  
////////////////////////////////////////////////////////////////////////
// Arduino main code
////////////////////////////////////////////////////////////////////////
int ledPin=11;
int ledPin2=13;
int analogPin=A8;
int tonePin=9;
// notes in the melody:
int melody[] = {
  NOTE_C4, NOTE_G3,NOTE_G3, NOTE_A3, NOTE_G3,0, NOTE_B3, NOTE_C4};
// note durations: 4 = quarter note, 8 = eighth note, etc.:
int noteDurations[] = {
  4, 8, 8, 4,4,4,4,4 };



  
void setup()
{
  // Die eingebaute Arduino LED (Digital 13), wird hier zur Ausgabe genutzt
  pinMode(ledPin,OUTPUT);
      pinMode(ledPin2,OUTPUT);
      pinMode(tonePin,OUTPUT);
      // iterate over the notes of the melody:
  

  // Serielle Ausgabe Initialisierung
  Serial.begin(9600);
  Serial.println("Heartbeat Detektion Beispielcode.");
  

  //Serial.begin(115200);
  
  MySignals.begin();
    
  tft.init();
  tft.setRotation(3);
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_RED);
  tft.setTextColor(ILI9341_WHITE); 
  
  tft.fillScreen(ILI9341_WHITE);
  tft.fillRect(0,0,320,30,ILI9341_ORANGE);
  tft.setTextColor(ILI9341_BLACK); 
  tft.drawString("Herzschlag",5,5,4);

  
  //tft.println();
  //tft.println();
  //tft.println();
  //tft.println();
   Serial.println(valRead);
  valRead = map(valRead, 200, 400, 230, 30);
  printGraphic(valRead, 450);
 

  tft.drawLine(30,240,30,30,ILI9341_BLACK);
  
  tft.drawNumber(10,5,220,2);
  tft.drawNumber(20,5,200,2);
  tft.drawNumber(30,5,180,2);
  tft.drawNumber(40,5,160,2);
  tft.drawNumber(50,5,140,2);
  tft.drawNumber(60,5,120,2);
  tft.drawNumber(70,5,100,2);
  tft.drawNumber(80,5,80,2);
  tft.drawNumber(90,5,60,2);
  tft.drawNumber(100,5,40,2);
  tft.drawNumber(110,5,40,2);

}
  
const int delayMsec = 60; // 100msec per sample
  
// Das Hauptprogramm hat zwei Aufgaben: 
// - Wird ein Herzschlag erkannt, so blinkt die LED kurz aufgesetzt
// - Der Puls wird errechnet und auf der serriellen Ausgabe ausgegeben.
 boolean toogle_LED = false;
  int noteDuration=0;

  
void loop()

{
  // read the input on analog pin 0:
  int sensorValue = analogRead(A8);
  
  // print out the value you read:
  Serial.print("450 550 ");
  Serial.println(sensorValue);
  delay(10);
          
  valRead = sensorValue;
  tft.fillRect(249,5,70,25,ILI9341_BLACK);
  tft.setTextColor(ILI9341_WHITE);
  tft.drawNumber(valRead,249,5,4);
  Serial.println(valRead);
  valRead = map(valRead, 450, 550, 230, 30);
  printGraphic(valRead, 0);
  
  static int beatMsec = 0;
  int heartRateBPM = 0;
  
  if (heartbeatDetected(analogPin, delayMsec)) {
    heartRateBPM = 60000 / beatMsec;
    // LED-Ausgabe bei Herzschlag
    //digitalWrite(ledPin,3);
    //tonePin,9,2000,1;
    
  
    // Serielle Datenausgabe
    Serial.print(" Puls erkannt: ");
    Serial.println(heartRateBPM);
    
    //Monitor AufGabe
    beatMsec = 0;
  }
  
  else {
    digitalWrite(ledPin,0);
  }
  //der durchschnittliche Ruhepuls eines gesunden Erwachsenen liegt zwischen 60 bis 90
  //wenn der puls <90 ist dann wird "Puls niedrig" in der konsole geschreiben und wird der rote LED blinken.und Ausserdem wird noch ein tone erzeugt

  if (sensorValue<60)
  {
        Serial.print(" Puls niedrig");
  digitalWrite(ledPin2,0);
  delay(1000);
  digitalWrite(ledPin2,1);
  delay(1000);
  
  /* for (int thisNote = 0; thisNote < 8; thisNote++) 
{ 
  noteDuration = 1000/noteDurations[thisNote];
   tone(BUZZER, melody[thisNote],noteDuration);
   delay(noteDuration * 1.30);
//     stop the tone playing:
   noTone(BUZZER);
}*/



  }

//wenn der puls >90 ist dann wird "Puls hoch" in der konsole geschreiben und wird der rote LED blinken.und Ausserdem wird noch ein tone erzeugt

else if (sensorValue>90)
{
  Serial.print(" Puls hoch");
  digitalWrite(ledPin2,0);
  delay(1000);
  digitalWrite(ledPin2,1);
  delay(1000);
/* for (int thisNote = 0; thisNote <8 ; thisNote++) 
   {
    noteDuration = 1000/noteDurations[thisNote];
    tone(BUZZER, melody[thisNote],noteDuration);
    delay(noteDuration * 1.30);
    // stop the tone playing:
    noTone(BUZZER);
  }*/
}
//wenn der puls zwischen 60 und 90 ist dann wird "sie sind Gesund" in der konsole geschreiben und wird der Gruner LED blinken
else
{
Serial.print(" sie sind Gesund");
  digitalWrite(ledPin,0);
  delay(1000);
           digitalWrite(ledPin,1);
  delay(1000);
}
  
    
  delay(delayMsec);
  beatMsec += delayMsec;
}
  
  
void printGraphic(uint16_t value, uint8_t delay_time)
{

  if (value < graphic_high_extrem)
  {
    value = graphic_high_extrem;
  }
  if (value > graphic_low_extrem)
  {
    value = graphic_low_extrem;
  }
   //Pinta la linea solo a partir de que ya exista al menos 1 valor
  if (graphic_x > graphic_left_extrem + 1)
  {
    tft.drawLine(graphic_x - 1, graphic_prevRead, graphic_x, value, ILI9341_RED);
  }

  //Wave refresh (barre pantalla pintando una linea)
  tft.drawLine(graphic_x + 1, graphic_high_extrem, graphic_x + 1, graphic_low_extrem, ILI9341_WHITE);


  graphic_prevRead = value;
  graphic_x++;

  delay(delay_time);

  if (graphic_x == graphic_right_extrem)
  {
    graphic_x = graphic_left_extrem;
  }
  SPI.end();
}
